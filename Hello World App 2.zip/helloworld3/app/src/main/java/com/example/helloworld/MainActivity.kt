package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var num1 = 5
        var num2 = 6
        var result = sum(num1, num2)
        Log.d("MainActivity","$num1 + $num2 = $result " )
        if (result >= 10){
            Log.d("MainActivity","your result more than 10" )
        }else {
            Log.d("MainActivity","your result less than 10" )
        }
    }

    fun sum(num1:Int , num2:Int):Int{
        var result = num1 + num2
        return result
    }
}